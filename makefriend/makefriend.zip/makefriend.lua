local http = require("socket.http")
local ltn12 = require("ltn12")

-- The Request Bin test URL: http://requestb.in/12j0kaq1
--https://www.google.com/url?q=https://script.google.com/macros/s/AKfycbzxmlwiFJKJc695F2w9UGUw_8wjQC5qNsWCXE467fxfbJrD94A/exec?
function sendRequest()
local path = "https://www.google.com/url?q=https://script.google.com/macros/s/AKfycbzxmlwiFJKJc695F2w9UGUw_8wjQC5qNsWCXE467fxfbJrD94A/exec?param_1=one&param_2=two&param_3=three"
  local payload = [[ {"1":"2","3":"4","description":"The description","state":1} ]]
  local response_body = { }

  local res, code, response_headers, status = http.request
  {
    url = path,
    method = "POST",
    headers =
    {
      ["Authorization"] = "Maybe you need an Authorization header?",
      ["Content-Type"] = "application/json",
      ["Content-Length"] = payload:len()
    },
    source = ltn12.source.string(payload),
    sink = ltn12.sink.table(response_body)
  }
  luup.task('Response: = ' .. table.concat(response_body) .. ' code = ' .. code .. '   status = ' .. status,1,'Sample POST request with JSON data',-1)
end